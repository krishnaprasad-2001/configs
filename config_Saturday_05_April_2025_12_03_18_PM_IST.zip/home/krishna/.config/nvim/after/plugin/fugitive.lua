vim.keymap.set("n","<leader>Gs", vim.cmd.Git)
