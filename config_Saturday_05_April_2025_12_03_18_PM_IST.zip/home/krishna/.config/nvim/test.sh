test=23
kokinachi=43
echo $kokinachi
