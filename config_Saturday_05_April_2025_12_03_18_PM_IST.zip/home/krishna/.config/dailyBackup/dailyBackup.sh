#!/bin/bash

backup_name=configuration_backup_$(date |tr " " _ |tr ":" _)
zip -r /root/configBackup/$backup_name /home/krishna/.config/dailyBackup
